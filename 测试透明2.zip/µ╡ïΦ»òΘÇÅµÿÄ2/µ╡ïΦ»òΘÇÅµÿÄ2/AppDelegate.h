//
//  AppDelegate.h
//  测试透明2
//
//  Created by juru on 2017/8/1.
//  Copyright © 2017年 juruyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

